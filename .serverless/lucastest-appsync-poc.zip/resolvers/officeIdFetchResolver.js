import { util } from '@aws-appsync/utils';
export function request (ctx) {
  // Inspect previous resolver result
  console.log('officeIdFetchResolver.request()', ctx.result, ctx.prev.result);
  return {
    version: "2018-05-29",
    operation: "Invoke",
    payload: {
      type: "Query",
      field: "getLucasTest",
      arguments: {
        previousResult: !!ctx.prev.result ? ctx.prev.result : null,
      }
    }
  };
}

export function response (ctx) {
  console.log('officeIdFetchResolver.response()', ctx.result, ctx.prev.result, ctx.stash);

  if (ctx.stash && ctx.stash.officeIdCacheResult) {
    console.log('officeIdFetchResolver.response() - returning cached result');
    return JSON.stringify([{ name: ctx.stash.officeIdCacheResult }]);
  }

  if (ctx.prev.result && ctx.prev.result.length > 0) {
    return JSON.stringify([{ name: 'early return' }]);
  }

  return JSON.stringify([{ name: 'normal return' }]);
}
